import SwiftUI
import UniformTypeIdentifiers

struct OpenedArchive: Identifiable, Hashable {
    let id = UUID()
    let url: URL      // рабочая копия во временной папке
    let name: String
}

struct HomeView: View {
    @State private var showCreate = false
    @State private var opened: OpenedArchive?
    @State private var toastText: String?

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()

                VStack(alignment: .leading, spacing: 0) {
                    Spacer().frame(height: 56)

                    Text("Архиватор")
                        .font(.system(size: 40, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                        .appear(0)

                    Text("ZIP с паролем. Работает без интернета")
                        .font(.system(size: 15))
                        .foregroundStyle(Color.white.opacity(0.65))
                        .padding(.top, 6)
                        .padding(.bottom, 36)
                        .appear(0.07)

                    Button { showCreate = true } label: {
                        HomeCard(
                            icon: "archivebox.fill",
                            title: "Создать архив",
                            subtitle: "Выберите файлы и при желании задайте пароль"
                        )
                    }
                    .buttonStyle(PressableStyle())
                    .appear(0.15)

                    Button { openArchive() } label: {
                        HomeCard(
                            icon: "folder.fill",
                            title: "Открыть архив",
                            subtitle: "Посмотреть содержимое, добавить файлы"
                        )
                    }
                    .buttonStyle(PressableStyle())
                    .padding(.top, 16)
                    .appear(0.23)

                    Spacer()

                    Text("Шифрование AES-256 · файлы не покидают телефон")
                        .font(.system(size: 12))
                        .foregroundStyle(Color.white.opacity(0.55))
                        .frame(maxWidth: .infinity)
                        .appear(0.32)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(isPresented: $showCreate) {
                CreateView()
            }
            .navigationDestination(item: $opened) { archive in
                ArchiveView(archive: archive)
            }
            .toast($toastText)
        }
    }

    private func openArchive() {
        Pickers.shared.pickFiles(types: [.zip], multiple: false) { urls in
            guard let url = urls.first else { return }
            do {
                let dir = try ZipService.newTempDir()
                let copy = try ZipService.adopt(url, into: dir)
                opened = OpenedArchive(url: copy, name: copy.lastPathComponent)
            } catch {
                toastText = "Не удалось открыть файл: \(error.localizedDescription)"
            }
        }
    }
}

private struct HomeCard: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 18) {
            IconBadge(systemName: icon, size: 56)
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 20, weight: .medium))
                    .foregroundStyle(Color.white)
                Text(subtitle)
                    .font(.system(size: 14))
                    .foregroundStyle(Color.white.opacity(0.65))
                    .multilineTextAlignment(.leading)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color.white.opacity(0.4))
        }
        .padding(22)
        .frame(maxWidth: .infinity)
        .glassCard(28)
    }
}
