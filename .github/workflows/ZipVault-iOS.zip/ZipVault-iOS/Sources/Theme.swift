import SwiftUI

// MARK: - Фон: плавающие цветные пятна

struct AuroraBackground: View {
    private struct Blob {
        let color: Color
        let x: Double
        let y: Double
        let radius: Double
        let phase: Double
    }

    private let blobs: [Blob] = [
        Blob(color: Color(red: 0.24, green: 0.42, blue: 1.00), x: 0.18, y: 0.16, radius: 0.62, phase: 0.0),
        Blob(color: Color(red: 0.54, green: 0.30, blue: 1.00), x: 0.92, y: 0.42, radius: 0.55, phase: 2.1),
        Blob(color: Color(red: 0.07, green: 0.71, blue: 0.65), x: 0.25, y: 0.92, radius: 0.65, phase: 4.2)
    ]

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate / 4.0
            GeometryReader { geo in
                let size = geo.size
                let m = max(size.width, size.height)
                ZStack {
                    Color(red: 0.043, green: 0.051, blue: 0.078)
                    ForEach(0..<blobs.count, id: \.self) { i in
                        let b = blobs[i]
                        let cx = (b.x + 0.05 * sin(t + b.phase)) * size.width
                        let cy = (b.y + 0.04 * cos(t + b.phase)) * size.height
                        let r = b.radius * m
                        Circle()
                            .fill(
                                RadialGradient(
                                    colors: [b.color.opacity(0.65), b.color.opacity(0.0)],
                                    center: .center,
                                    startRadius: 0,
                                    endRadius: r
                                )
                            )
                            .frame(width: r * 2, height: r * 2)
                            .position(x: cx, y: cy)
                    }
                }
                .frame(width: size.width, height: size.height)
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Матовое стекло

struct GlassCard: ViewModifier {
    var radius: CGFloat

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(
                        LinearGradient(
                            colors: [Color.white.opacity(0.38), Color.white.opacity(0.06)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
            )
    }
}

extension View {
    func glassCard(_ radius: CGFloat = 28) -> some View {
        modifier(GlassCard(radius: radius))
    }

    func appear(_ delay: Double = 0) -> some View {
        modifier(AppearModifier(delay: delay))
    }

    func toast(_ message: Binding<String?>) -> some View {
        modifier(ToastModifier(message: message))
    }
}

// MARK: - Плавное появление

struct AppearModifier: ViewModifier {
    let delay: Double
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 24)
            .onAppear {
                withAnimation(.spring(duration: 0.6, bounce: 0.15).delay(delay)) {
                    shown = true
                }
            }
    }
}

// MARK: - Кнопки

private struct PrimaryButtonBody: View {
    let configuration: ButtonStyleConfiguration
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        configuration.label
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(isEnabled ? Color.white : Color.white.opacity(0.4))
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background {
                if isEnabled {
                    Capsule().fill(
                        LinearGradient(
                            colors: [Color(red: 0.29, green: 0.56, blue: 1.0), Color(red: 0.49, green: 0.42, blue: 1.0)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                } else {
                    Capsule().fill(Color.white.opacity(0.12))
                }
            }
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        PrimaryButtonBody(configuration: configuration)
    }
}

private struct GlassButtonBody: View {
    let configuration: ButtonStyleConfiguration
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        configuration.label
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(isEnabled ? Color.white : Color.white.opacity(0.4))
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(isEnabled ? 0.28 : 0.12), lineWidth: 1))
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct GlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        GlassButtonBody(configuration: configuration)
    }
}

/// Лёгкое «вдавливание» для больших карточек.
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// MARK: - Элементы списка

struct IconBadge: View {
    let systemName: String
    var size: CGFloat = 52

    var body: some View {
        Circle()
            .fill(
                LinearGradient(
                    colors: [Color(red: 0.29, green: 0.56, blue: 1.0).opacity(0.65),
                             Color(red: 0.49, green: 0.42, blue: 1.0).opacity(0.65)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(Circle().strokeBorder(Color.white.opacity(0.22), lineWidth: 1))
            .overlay(
                Image(systemName: systemName)
                    .font(.system(size: size * 0.42, weight: .medium))
                    .foregroundStyle(Color.white)
            )
            .frame(width: size, height: size)
    }
}

struct FileRow: View {
    let title: String
    let subtitle: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 14) {
            IconBadge(systemName: systemImage, size: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 16))
                    .foregroundStyle(Color.white)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundStyle(Color.white.opacity(0.6))
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

// MARK: - Всплывающее сообщение

struct ToastModifier: ViewModifier {
    @Binding var message: String?

    func body(content: Content) -> some View {
        content
            .overlay(alignment: .bottom) {
                if let m = message {
                    Text(m)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(Color.white)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .glassCard(22)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 96)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                        .task(id: m) {
                            try? await Task.sleep(nanoseconds: 2_800_000_000)
                            withAnimation { message = nil }
                        }
                }
            }
            .animation(.spring(duration: 0.4), value: message)
    }
}
