import SwiftUI

@main
struct ZipVaultApp: App {
    init() {
        // Убираем временные файлы от прошлых запусков.
        ZipService.cleanTemp()
    }

    var body: some Scene {
        WindowGroup {
            HomeView()
                .preferredColorScheme(.dark)
                .tint(Color.white)
        }
    }
}
