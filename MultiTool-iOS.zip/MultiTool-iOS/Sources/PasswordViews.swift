import SwiftUI
import UIKit

private let wordList: [String] = {
    guard let url = Bundle.main.url(forResource: "wordlist_en", withExtension: "txt"),
          let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
    return text.split(whereSeparator: { $0 == "\n" || $0 == "\r" }).map { String($0) }.filter { !$0.isEmpty }
}()

// MARK: - Меню раздела

struct PasswordMenuView: View {
    @State private var showGenerator = false
    @State private var showChecker = false

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ScreenTitle(title: "Пароли", subtitle: "Всё считается на телефоне, ничего не отправляется")
                        .padding(.bottom, 20)
                        .appear(0)

                    Button { showGenerator = true } label: {
                        MenuCard(icon: "key.fill", title: "Генератор",
                                 subtitle: "Пароль, парольная фраза или PIN")
                    }
                    .buttonStyle(PressableStyle())
                    .appear(0.1)

                    Button { showChecker = true } label: {
                        MenuCard(icon: "checkmark.shield.fill", title: "Проверка надёжности",
                                 subtitle: "Оценка пароля и время подбора")
                    }
                    .buttonStyle(PressableStyle())
                    .appear(0.18)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .navigationDestination(isPresented: $showGenerator) { GeneratorView() }
        .navigationDestination(isPresented: $showChecker) { CheckerView() }
    }
}

// MARK: - Общие элементы

private struct ToggleChip: View {
    let title: String
    @Binding var isOn: Bool

    var body: some View {
        Button { isOn.toggle() } label: {
            Text(title)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(Color.white)
                .frame(maxWidth: .infinity)
                .frame(height: 42)
                .background(isOn ? Color(red: 0.29, green: 0.56, blue: 1.0).opacity(0.4) : Color.white.opacity(0.1),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(isOn ? Color(red: 0.29, green: 0.56, blue: 1.0) : Color.white.opacity(0.25),
                                      lineWidth: isOn ? 1.5 : 1)
                )
        }
        .buttonStyle(PressableStyle())
    }
}

private func strengthColor(_ score: Int) -> Color {
    switch score {
    case 0: return Color(red: 1.0, green: 0.33, blue: 0.33)
    case 1: return Color(red: 1.0, green: 0.55, blue: 0.2)
    case 2: return Color(red: 1.0, green: 0.8, blue: 0.2)
    case 3: return Color(red: 0.55, green: 0.85, blue: 0.4)
    default: return Color(red: 0.2, green: 0.85, blue: 0.55)
    }
}

private struct StrengthBar: View {
    let score: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<5, id: \.self) { i in
                Capsule()
                    .fill(i <= score ? strengthColor(score) : Color.white.opacity(0.15))
                    .frame(height: 8)
            }
        }
    }
}

// MARK: - Генератор

struct GeneratorView: View {
    @State private var mode = 0                 // 0 пароль, 1 фраза, 2 PIN
    @State private var length = 16.0
    @State private var words = 5.0
    @State private var pinLength = 6.0
    @State private var useLower = true
    @State private var useUpper = true
    @State private var useDigits = true
    @State private var useSymbols = true
    @State private var noAmbiguous = false
    @State private var capitalize = true
    @State private var addNumber = true
    @State private var separator = "-"
    @State private var result = ""
    @State private var toastText: String?

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ScreenTitle(title: "Генератор", subtitle: "Случайные значения, создаются на телефоне")
                        .padding(.bottom, 4)

                    Picker("Тип", selection: $mode) {
                        Text("Пароль").tag(0)
                        Text("Фраза").tag(1)
                        Text("PIN").tag(2)
                    }
                    .pickerStyle(.segmented)

                    VStack(alignment: .leading, spacing: 14) {
                        Text(result.isEmpty ? " " : result)
                            .font(.system(size: 22, weight: .regular, design: .monospaced))
                            .foregroundStyle(Color.white)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)

                        StrengthBar(score: PasswordTools.levelFor(bits))
                        Text("Энтропия: \(Int(bits)) бит · \(PasswordTools.labelFor(PasswordTools.levelFor(bits)))")
                            .font(.system(size: 14))
                            .foregroundStyle(Color.white.opacity(0.65))

                        HStack(spacing: 12) {
                            Button("Обновить") { regenerate() }
                                .buttonStyle(GlassButtonStyle())
                            Button("Копировать") {
                                UIPasteboard.general.string = result
                                toastText = "Скопировано"
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(20)
                    .glassCard(24)

                    VStack(alignment: .leading, spacing: 14) {
                        if mode == 0 {
                            Text("Длина: \(Int(length))").foregroundStyle(Color.white)
                            Slider(value: $length, in: 6...64, step: 1)
                            HStack(spacing: 8) {
                                ToggleChip(title: "a–z", isOn: $useLower)
                                ToggleChip(title: "A–Z", isOn: $useUpper)
                                ToggleChip(title: "0–9", isOn: $useDigits)
                                ToggleChip(title: "!@#", isOn: $useSymbols)
                            }
                            Toggle("Без похожих символов (O и 0, l и 1)", isOn: $noAmbiguous)
                                .foregroundStyle(Color.white)
                        } else if mode == 1 {
                            Text("Слов: \(Int(words))").foregroundStyle(Color.white)
                            Slider(value: $words, in: 3...10, step: 1)
                            Toggle("Заглавные буквы", isOn: $capitalize).foregroundStyle(Color.white)
                            Toggle("Число в конце", isOn: $addNumber).foregroundStyle(Color.white)
                            Picker("Разделитель", selection: $separator) {
                                Text("-").tag("-")
                                Text(".").tag(".")
                                Text("_").tag("_")
                                Text("пробел").tag(" ")
                                Text("нет").tag("")
                            }
                            .pickerStyle(.segmented)
                        } else {
                            Text("Цифр: \(Int(pinLength))").foregroundStyle(Color.white)
                            Slider(value: $pinLength, in: 4...12, step: 1)
                        }
                    }
                    .padding(20)
                    .glassCard(24)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .toast($toastText)
        .onAppear { regenerate() }
        .onChange(of: mode) { regenerate() }
        .onChange(of: length) { regenerate() }
        .onChange(of: words) { regenerate() }
        .onChange(of: pinLength) { regenerate() }
        .onChange(of: useLower) { ensureSet(); regenerate() }
        .onChange(of: useUpper) { ensureSet(); regenerate() }
        .onChange(of: useDigits) { ensureSet(); regenerate() }
        .onChange(of: useSymbols) { ensureSet(); regenerate() }
        .onChange(of: noAmbiguous) { regenerate() }
        .onChange(of: capitalize) { regenerate() }
        .onChange(of: addNumber) { regenerate() }
        .onChange(of: separator) { regenerate() }
    }

    private var bits: Double {
        switch mode {
        case 0:
            let pool = PasswordTools.poolSize(lower: useLower, upper: useUpper, digits: useDigits,
                                              symbols: useSymbols, noAmbiguous: noAmbiguous)
            return PasswordTools.passwordBits(length: Int(length), pool: pool)
        case 1:
            return PasswordTools.phraseBits(words: Int(words), listSize: wordList.count, addNumber: addNumber)
        default:
            return PasswordTools.pinBits(length: Int(pinLength))
        }
    }

    /// Хотя бы один набор символов должен остаться включённым.
    private func ensureSet() {
        if !useLower && !useUpper && !useDigits && !useSymbols { useLower = true }
    }

    private func regenerate() {
        switch mode {
        case 0:
            result = PasswordTools.generate(length: Int(length), lower: useLower, upper: useUpper,
                                            digits: useDigits, symbols: useSymbols, noAmbiguous: noAmbiguous)
        case 1:
            result = PasswordTools.passphrase(words: Int(words), separator: separator, capitalize: capitalize,
                                              addNumber: addNumber, list: wordList)
        default:
            result = PasswordTools.pin(length: Int(pinLength))
        }
    }
}

// MARK: - Проверка надёжности

struct CheckerView: View {
    @State private var password = ""
    @State private var show = false

    var body: some View {
        let report = PasswordTools.analyze(password)
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ScreenTitle(title: "Проверка", subtitle: "Пароль не сохраняется и никуда не уходит")
                        .padding(.bottom, 4)

                    HStack {
                        Group {
                            if show {
                                TextField("Введите пароль", text: $password)
                            } else {
                                SecureField("Введите пароль", text: $password)
                            }
                        }
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .foregroundStyle(Color.white)
                        Button { show.toggle() } label: {
                            Image(systemName: show ? "eye.slash" : "eye")
                                .foregroundStyle(Color.white.opacity(0.7))
                        }
                    }
                    .padding(16)
                    .glassCard(20)

                    if !password.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            StrengthBar(score: report.score)
                            Text("\(report.label) · \(Int(report.bits)) бит")
                                .font(.system(size: 18, weight: .medium))
                                .foregroundStyle(strengthColor(report.score))
                            Text("Быстрый перебор: \(report.crackOffline)")
                                .font(.system(size: 14))
                                .foregroundStyle(Color.white.opacity(0.7))
                            Text("Подбор через форму входа: \(report.crackOnline)")
                                .font(.system(size: 14))
                                .foregroundStyle(Color.white.opacity(0.7))
                        }
                        .padding(20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .glassCard(24)

                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(0..<report.tips.count, id: \.self) { i in
                                Text("• " + report.tips[i])
                                    .font(.system(size: 14))
                                    .foregroundStyle(Color.white.opacity(0.85))
                            }
                        }
                        .padding(20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .glassCard(24)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
    }
}
