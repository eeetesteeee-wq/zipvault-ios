import SwiftUI

/// Настройки: выбор фона приложения.
struct SettingsView: View {
    @AppStorage("background") private var background: Int = 0

    private let options: [(id: Int, title: String, subtitle: String)] = [
        (0, "Аврора", "Живое цветное сияние"),
        (1, "Ночное свечение", "Тёмно-синий мягкий градиент"),
        (2, "Закат", "Тёплое сияние: оранжевый, розовый, фиолетовый")
    ]

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ScreenTitle(title: "Настройки", subtitle: "Фон приложения")
                        .padding(.bottom, 12)
                        .appear(0)

                    ForEach(0..<options.count, id: \.self) { i in
                        let o = options[i]
                        Button {
                            withAnimation(.easeInOut(duration: 0.3)) { background = o.id }
                        } label: {
                            ZStack(alignment: .bottomLeading) {
                                AuroraBackground(forced: o.id)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(o.title)
                                        .font(.system(size: 18, weight: .medium))
                                        .foregroundStyle(Color.white)
                                    Text(o.subtitle)
                                        .font(.system(size: 13))
                                        .foregroundStyle(Color.white.opacity(0.7))
                                }
                                .padding(18)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(
                                    LinearGradient(colors: [Color.clear, Color.black.opacity(0.55)],
                                                   startPoint: .top, endPoint: .bottom)
                                )
                            }
                            .frame(height: 170)
                            .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 26, style: .continuous)
                                    .strokeBorder(background == o.id ? Color(red: 0.29, green: 0.56, blue: 1.0)
                                                  : Color.white.opacity(0.25),
                                                  lineWidth: background == o.id ? 2 : 1)
                            )
                            .overlay(alignment: .topTrailing) {
                                if background == o.id {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 14, weight: .bold))
                                        .foregroundStyle(Color.white)
                                        .frame(width: 34, height: 34)
                                        .background(.ultraThinMaterial, in: Circle())
                                        .padding(12)
                                }
                            }
                        }
                        .buttonStyle(PressableStyle())
                        .appear(0.08 * Double(i + 1))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
    }
}
