import Foundation
import ZipArchive

struct ArchiveEntry: Identifiable, Hashable {
    var id: String { path }
    let path: String
    let size: Int64
    let isDirectory: Bool
}

enum ZipServiceError: LocalizedError {
    case createFailed

    var errorDescription: String? {
        switch self {
        case .createFailed:
            return "Не удалось создать архив"
        }
    }
}

func formatSize(_ bytes: Int64) -> String {
    ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
}

enum ZipService {

    // MARK: - временные папки и копирование

    static func newTempDir() throws -> URL {
        let dir = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func cleanTemp() {
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory
        let items = (try? fm.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil)) ?? []
        for item in items {
            try? fm.removeItem(at: item)
        }
    }

    /// Свободное имя в папке: «file.txt» → «file (1).txt».
    static func uniqueURL(in dir: URL, name: String) -> URL {
        let fm = FileManager.default
        var candidate = dir.appendingPathComponent(name)
        if !fm.fileExists(atPath: candidate.path) { return candidate }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var i = 1
        repeat {
            let n = ext.isEmpty ? "\(base) (\(i))" : "\(base) (\(i)).\(ext)"
            candidate = dir.appendingPathComponent(n)
            i += 1
        } while fm.fileExists(atPath: candidate.path)
        return candidate
    }

    /// Копирует выбранный в «Файлах» объект к нам в папку dir (нужен доступ security-scoped).
    static func importCopy(_ url: URL, into dir: URL) throws -> URL {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let dest = uniqueURL(in: dir, name: url.lastPathComponent)
        try FileManager.default.copyItem(at: url, to: dest)
        return dest
    }

    /// Забирает уже скопированный нам файл в папку dir: перемещает, а если не вышло, копирует.
    static func adopt(_ url: URL, into dir: URL) throws -> URL {
        let dest = uniqueURL(in: dir, name: url.lastPathComponent)
        do {
            try FileManager.default.moveItem(at: url, to: dest)
        } catch {
            try FileManager.default.copyItem(at: url, to: dest)
        }
        return dest
    }

    static func fileSize(_ url: URL) -> Int64 {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        return Int64(values?.fileSize ?? 0)
    }

    // MARK: - работа с архивом

    static func isEncrypted(_ archive: URL) -> Bool {
        SSZipArchive.isFilePasswordProtected(atPath: archive.path)
    }

    /// Распаковывает архив во временную папку. С неверным паролем бросает ошибку.
    static func extract(archive: URL, password: String?) throws -> URL {
        let dir = try newTempDir()
        let pwd = (password?.isEmpty == false) ? password : nil
        do {
            _ = try SSZipArchive.unzipFile(
                atPath: archive.path,
                toDestination: dir.path,
                overwrite: true,
                password: pwd
            )
        } catch {
            try? FileManager.default.removeItem(at: dir)
            throw error
        }
        return dir
    }

    /// Список файлов и папок внутри распакованного архива.
    static func list(_ dir: URL) -> [ArchiveEntry] {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey]
        guard let walker = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: keys) else {
            return []
        }
        let base = dir.resolvingSymlinksInPath().path
        var result: [ArchiveEntry] = []
        for case let url as URL in walker {
            var rel = url.resolvingSymlinksInPath().path
            if rel.hasPrefix(base) { rel = String(rel.dropFirst(base.count)) }
            if rel.hasPrefix("/") { rel.removeFirst() }
            if rel.isEmpty || rel.hasPrefix("__MACOSX") { continue }
            let values = try? url.resourceValues(forKeys: Set(keys))
            result.append(ArchiveEntry(
                path: rel,
                size: Int64(values?.fileSize ?? 0),
                isDirectory: values?.isDirectory ?? false
            ))
        }
        return result.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    /// Копия файла из архива во временной папке, чтобы отдать её в «Файлы».
    static func stageForExport(workDir: URL, relativePath: String) throws -> URL {
        let src = workDir.appendingPathComponent(relativePath)
        let dest = try newTempDir().appendingPathComponent(src.lastPathComponent)
        try FileManager.default.copyItem(at: src, to: dest)
        return dest
    }

    /// Собирает zip из всего содержимого папки. Пароль даёт AES-шифрование.
    static func buildArchive(from dir: URL, name: String, password: String?) throws -> URL {
        var safe = name
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if safe.isEmpty { safe = "Архив" }
        let out = try newTempDir().appendingPathComponent(safe + ".zip")
        let pwd = (password?.isEmpty == false) ? password : nil
        let ok = SSZipArchive.createZipFile(
            atPath: out.path,
            withContentsOfDirectory: dir.path,
            keepParentDirectory: false,
            withPassword: pwd
        )
        if !ok { throw ZipServiceError.createFailed }
        return out
    }
}
