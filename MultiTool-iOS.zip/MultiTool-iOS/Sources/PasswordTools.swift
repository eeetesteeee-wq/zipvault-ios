import Foundation

/// Генерация паролей, парольных фраз и оценка надёжности. Всё офлайн.
enum PasswordTools {
    static let lower = "abcdefghijklmnopqrstuvwxyz"
    static let upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    static let digits = "0123456789"
    static let symbols = "!@#$%^&*()-_=+[]{};:,.?/"
    static let ambiguous = "O0oIl1|`'\""

    // MARK: - Генерация

    private static func strip(_ set: String, _ noAmbiguous: Bool) -> [Character] {
        let chars = Array(set)
        if !noAmbiguous { return chars }
        return chars.filter { !ambiguous.contains($0) }
    }

    static func poolSize(lower l: Bool, upper u: Bool, digits d: Bool, symbols s: Bool, noAmbiguous: Bool) -> Int {
        var n = 0
        if l { n += strip(lower, noAmbiguous).count }
        if u { n += strip(upper, noAmbiguous).count }
        if d { n += strip(digits, noAmbiguous).count }
        if s { n += strip(symbols, noAmbiguous).count }
        return n
    }

    /// Случайный пароль: минимум по одному символу из каждого выбранного набора.
    static func generate(length: Int, lower l: Bool, upper u: Bool, digits d: Bool, symbols s: Bool,
                         noAmbiguous: Bool) -> String {
        var sets: [[Character]] = []
        if l { sets.append(strip(lower, noAmbiguous)) }
        if u { sets.append(strip(upper, noAmbiguous)) }
        if d { sets.append(strip(digits, noAmbiguous)) }
        if s { sets.append(strip(symbols, noAmbiguous)) }
        if sets.isEmpty { return "" }
        let len = max(length, sets.count)
        let pool = sets.flatMap { $0 }
        var out: [Character] = []
        for set in sets { out.append(set[Int.random(in: 0..<set.count)]) }
        while out.count < len { out.append(pool[Int.random(in: 0..<pool.count)]) }
        out.shuffle()
        return String(out)
    }

    static func pin(length: Int) -> String {
        var s = ""
        for _ in 0..<length { s.append(String(Int.random(in: 0..<10))) }
        return s
    }

    static func passphrase(words: Int, separator: String, capitalize: Bool, addNumber: Bool, list: [String]) -> String {
        if list.isEmpty { return "" }
        var parts: [String] = []
        for _ in 0..<words {
            var w = list[Int.random(in: 0..<list.count)]
            if capitalize, let f = w.first { w = String(f).uppercased() + w.dropFirst() }
            parts.append(w)
        }
        var s = parts.joined(separator: separator)
        if addNumber { s += separator + String(Int.random(in: 0..<100)) }
        return s
    }

    static func passwordBits(length: Int, pool: Int) -> Double {
        pool <= 1 ? 0 : Double(length) * log2(Double(pool))
    }

    static func phraseBits(words: Int, listSize: Int, addNumber: Bool) -> Double {
        var b = Double(words) * log2(Double(max(listSize, 1)))
        if addNumber { b += log2(100.0) }
        return b
    }

    static func pinBits(length: Int) -> Double { Double(length) * log2(10.0) }

    // MARK: - Оценка надёжности

    struct Report {
        var bits: Double = 0
        var score: Int = 0
        var label: String = ""
        var crackOffline: String = ""
        var crackOnline: String = ""
        var common = false
        var tips: [String] = []
    }

    private static let commonList: [String] = (
        "123456 password 12345678 qwerty 123456789 12345 1234 111111 1234567 dragon 123123 baseball abc123 football "
        + "monkey letmein 696969 shadow master 666666 qwertyuiop 123321 mustang 1234567890 michael 654321 superman "
        + "1qaz2wsx 7777777 121212 000000 qazwsx 123qwe killer trustno1 jordan jennifer zxcvbnm asdfgh hunter buster "
        + "soccer harley batman andrew tigger sunshine iloveyou 2000 charlie robert thomas hockey ranger daniel starwars "
        + "klaster 112233 george computer michelle jessica pepper 1111 zxcvbn 555555 11111111 131313 freedom 777777 "
        + "pass maggie 159753 aaaaaa ginger princess joshua cheese amanda summer love ashley 6969 nicole chelsea biteme "
        + "matthew access yankees 987654321 dallas austin thunder taylor matrix admin welcome login passw0rd password1 "
        + "qwerty123 qwerty1 1q2w3e4r 1q2w3e 1q2w3e4r5t q1w2e3r4 zaq12wsx admin123 root toor test guest user default "
        + "secret changeme letmein1 monkey1 dragon1 football1 iloveyou1 sunshine1 princess1 abc12345 qweasd qweasdzxc "
        + "123654 123456a a123456 1234qwer qwer1234 asdf1234 pa55word p4ssw0rd master1 hello hello123 whatever "
        + "ninja azerty google facebook samsung android iphone apple banana cookie mother father family friend "
        + "йцукен ячсмить пароль привет любовь россия москва qwertyu asdfghjkl zxcvbnm1 1qazxsw2 samsung1 nokia "
        + "ghbdtn ghbdtnbr gfhjkm qazwsxedc password123 passwd 00000000 12341234 11223344 987654321 0987654321 "
        + "gfhjkmgfhjkm nastya natasha sergey dima alex vasya sasha masha"
    ).split(separator: " ").map(String.init)

    private static let commonRank: [String: Int] = {
        var m: [String: Int] = [:]
        for (i, w) in commonList.enumerated() where m[w] == nil { m[w] = i + 1 }
        return m
    }()

    private static let keyRows = [
        "qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890",
        "йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"
    ]

    private static func deLeet(_ s: [Character]) -> [Character] {
        s.map { c in
            switch c {
            case "0": return "o"
            case "1": return "l"
            case "3": return "e"
            case "4": return "a"
            case "5": return "s"
            case "7": return "t"
            case "@": return "a"
            case "$": return "s"
            case "!": return "i"
            default: return c
            }
        }
    }

    private static func isVowel(_ c: Character) -> Bool { "aeiouyаеёиоуыэюя".contains(c) }

    private static func wordLike(original: [Character], lower: [Character]) -> [Bool] {
        let n = lower.count
        var res = [Bool](repeating: false, count: n)
        let d = deLeet(lower)
        var i = 0
        while i < n {
            if !d[i].isLetter { i += 1; continue }
            var j = i
            while j < n && d[j].isLetter { j += 1 }
            let len = j - i
            if len >= 4 {
                var vowels = 0, orig = 0, maxCons = 0, cons = 0
                for k in i..<j {
                    if isVowel(d[k]) { vowels += 1; cons = 0 } else { cons += 1; maxCons = max(maxCons, cons) }
                    if lower[k].isLetter { orig += 1 }
                }
                let vr = Double(vowels) / Double(len)
                var upperCount = 0
                let firstUpper = original[i].isUppercase
                for k in i..<j where original[k].isUppercase { upperCount += 1 }
                let caseOk = upperCount == 0 || (upperCount == 1 && firstUpper) || upperCount == len
                if vr >= 0.28 && vr <= 0.6 && maxCons <= 3 && Double(orig) >= 0.6 * Double(len) && caseOk {
                    for k in i..<j { res[k] = true }
                }
            }
            i = j
        }
        return res
    }

    private static func trimTail(_ t: [Character]) -> [Character]? {
        var end = t.count
        while end > 0 && !t[end - 1].isLetter { end -= 1 }
        if end > 0 && end < t.count { return Array(t[0..<end]) }
        return nil
    }

    private static func rankOf(_ lowerPw: [Character]) -> Int {
        if let r = commonRank[String(lowerPw)] { return r }
        if let cut = trimTail(lowerPw), let r = commonRank[String(cut)] { return r }
        let d = deLeet(lowerPw)
        if let r = commonRank[String(d)] { return r }
        if let cut = trimTail(d), let r = commonRank[String(cut)] { return r }
        return -1
    }

    private static func inKeyboardRun(_ lower: [Character], _ i: Int) -> Bool {
        var start = max(0, i - 2)
        while start <= i && start + 3 <= lower.count {
            let sub = String(lower[start..<(start + 3)])
            let rev = String(sub.reversed())
            for row in keyRows where row.contains(sub) || row.contains(rev) { return true }
            start += 1
        }
        return false
    }

    private static func code(_ c: Character) -> Int { Int(c.unicodeScalars.first?.value ?? 0) }

    static func analyze(_ pw: String) -> Report {
        var r = Report()
        if pw.isEmpty {
            r.label = "Введите пароль"
            return r
        }
        let original = Array(pw)
        let lower: [Character] = original.map { Character(String($0).lowercased().first ?? $0) }
        let n = original.count

        var hasLower = false, hasUpper = false, hasDigit = false, hasSym = false, hasOther = false
        for c in original {
            let v = code(c)
            if v >= 97 && v <= 122 { hasLower = true }
            else if v >= 65 && v <= 90 { hasUpper = true }
            else if v >= 48 && v <= 57 { hasDigit = true }
            else if v < 128 { hasSym = true }
            else { hasOther = true }
        }
        var pool = 0
        if hasLower { pool += 26 }
        if hasUpper { pool += 26 }
        if hasDigit { pool += 10 }
        if hasSym { pool += 33 }
        if hasOther { pool += 66 }
        let perChar = log2(Double(max(pool, 2)))

        var bits = 0.0
        var seqChars = 0, repChars = 0
        var dir = 0
        let word = wordLike(original: original, lower: lower)
        var wordPart = 0.0
        var runs = 0
        for i in 0..<n where word[i] && (i == 0 || !word[i - 1]) { runs += 1 }
        for i in 0..<n {
            let c = lower[i]
            var cost = perChar
            let sepBetween = i > 0 && i + 1 < n && word[i - 1] && word[i + 1] && " -_.,".contains(original[i])
            if sepBetween {
                cost = 3
            } else if word[i] {
                cost = 2.8
                let oc = code(original[i])
                if !(oc >= 97 && oc <= 122) && !(oc >= 0x430 && oc <= 0x44F) { cost += 1.5 }
            }
            if i > 0 {
                let diff = code(c) - code(lower[i - 1])
                if diff == 0 {
                    cost = 1
                    repChars += 1
                    dir = 0
                } else if diff == 1 || diff == -1 {
                    if dir == diff {
                        cost = 1
                        seqChars += 1
                    } else {
                        dir = diff
                        cost = min(perChar, 3)
                    }
                } else {
                    dir = 0
                    if i >= 2 && inKeyboardRun(lower, i) {
                        cost = 1.5
                        seqChars += 1
                    }
                }
            }
            if word[i] { wordPart += cost }
            bits += cost
        }
        let wordCap = Double(runs) * 13.0
        if wordPart > wordCap { bits -= (wordPart - wordCap) }

        let rank = rankOf(lower)
        if rank > 0 {
            r.common = true
            let commonBits = log2(Double(rank + 1)) + 3
            if commonBits < bits { bits = commonBits }
        }
        if !hasLower && !hasUpper && !hasSym && !hasOther {
            bits = min(bits, Double(n) * log2(10.0))
        }
        r.bits = bits
        r.score = levelFor(bits)
        r.label = labelFor(r.score)

        let guesses = pow(2.0, max(bits - 1, 0))
        r.crackOffline = humanTime(guesses / 1e10)
        r.crackOnline = humanTime(guesses / 10.0)

        if r.common { r.tips.append("Этот пароль или его вариант есть среди самых популярных, его подберут первым") }
        if n < 12 { r.tips.append("Сделайте длиннее: лучше 12 символов и больше") }
        if !(hasLower && hasUpper) && !hasOther { r.tips.append("Смешайте строчные и заглавные буквы") }
        if !hasDigit { r.tips.append("Добавьте цифры") }
        if !hasSym && n < 16 { r.tips.append("Добавьте знаки вроде ! # ?") }
        if seqChars >= 3 { r.tips.append("Есть последовательности (abc, 123, qwerty), их легко угадать") }
        if repChars >= 2 { r.tips.append("Есть повторяющиеся символы") }
        if r.tips.isEmpty { r.tips.append("Отличный пароль. Не используйте его на разных сайтах") }
        return r
    }

    static func levelFor(_ bits: Double) -> Int {
        if bits < 28 { return 0 }
        if bits < 40 { return 1 }
        if bits < 60 { return 2 }
        if bits < 80 { return 3 }
        return 4
    }

    static func labelFor(_ score: Int) -> String {
        switch score {
        case 0: return "Очень слабый"
        case 1: return "Слабый"
        case 2: return "Средний"
        case 3: return "Хороший"
        default: return "Отличный"
        }
    }

    static func humanTime(_ seconds: Double) -> String {
        if seconds < 1 { return "мгновенно" }
        if seconds < 60 { return plural(Int(seconds), "секунда", "секунды", "секунд") }
        let minutes = seconds / 60
        if minutes < 60 { return plural(Int(minutes), "минута", "минуты", "минут") }
        let hours = minutes / 60
        if hours < 24 { return plural(Int(hours), "час", "часа", "часов") }
        let days = hours / 24
        if days < 365 { return plural(Int(days), "день", "дня", "дней") }
        let years = days / 365
        if years < 1000 { return plural(Int(years), "год", "года", "лет") }
        if years < 1e6 { return plural(Int(years / 1000), "тысяча лет", "тысячи лет", "тысяч лет") }
        if years < 1e9 { return plural(Int(years / 1e6), "миллион лет", "миллиона лет", "миллионов лет") }
        if years < 1e12 { return plural(Int(years / 1e9), "миллиард лет", "миллиарда лет", "миллиардов лет") }
        return "дольше возраста Вселенной"
    }

    private static func plural(_ n: Int, _ one: String, _ few: String, _ many: String) -> String {
        let m100 = n % 100, m10 = n % 10
        let w: String
        if m100 >= 11 && m100 <= 14 { w = many }
        else if m10 == 1 { w = one }
        else if m10 >= 2 && m10 <= 4 { w = few }
        else { w = many }
        return "\(n) \(w)"
    }
}
