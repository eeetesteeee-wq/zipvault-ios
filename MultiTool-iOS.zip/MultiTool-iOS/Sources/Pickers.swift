import UIKit
import PhotosUI
import UniformTypeIdentifiers

/// Нативные окна выбора файлов и фото/видео (UIKit).
/// Работают надёжнее SwiftUI-модификаторов fileImporter/fileMover, которые на одном экране мешают друг другу.
final class Pickers: NSObject {
    static let shared = Pickers()

    private var openCompletion: (([URL]) -> Void)?
    private var exportCompletion: ((Bool) -> Void)?
    private var mediaCompletion: (([URL]) -> Void)?
    private var mediaLoading: (() -> Void)?

    // MARK: - Публичные методы

    /// Выбор файлов из приложения «Файлы». Система сразу отдаёт копии, доступ к исходникам не нужен.
    func pickFiles(types: [UTType], multiple: Bool, completion: @escaping ([URL]) -> Void) {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.allowsMultipleSelection = multiple
        picker.delegate = self
        openCompletion = completion
        present(picker)
    }

    /// Выбор фото и видео из галереи. Разрешение на доступ к фото не требуется.
    /// onLoading вызывается, когда пользователь подтвердил выбор и началась загрузка файлов.
    func pickMedia(onLoading: @escaping () -> Void, completion: @escaping ([URL]) -> Void) {
        var config = PHPickerConfiguration()
        config.filter = .any(of: [.images, .videos])
        config.selectionLimit = 0                      // без ограничения
        config.preferredAssetRepresentationMode = .current   // без перекодирования
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        mediaLoading = onLoading
        mediaCompletion = completion
        present(picker)
    }

    /// Окно «Сохранить в Файлы». completion(true), если файл сохранён.
    func exportFile(_ url: URL, completion: @escaping (Bool) -> Void) {
        let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        picker.delegate = self
        exportCompletion = completion
        present(picker)
    }

    // MARK: - Показ

    private func present(_ vc: UIViewController) {
        // Небольшая пауза, чтобы закрылось меню выбора источника.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            guard let top = Pickers.topViewController() else { return }
            top.present(vc, animated: true)
        }
    }

    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            ?? scene?.windows.first?.rootViewController
        while let presented = top?.presentedViewController {
            top = presented
        }
        return top
    }
}

// MARK: - Файлы

extension Pickers: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let done = exportCompletion {
            exportCompletion = nil
            done(true)
            return
        }
        if let done = openCompletion {
            openCompletion = nil
            done(urls)
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        if let done = exportCompletion {
            exportCompletion = nil
            done(false)
        }
        openCompletion = nil
    }
}

// MARK: - Фото и видео

extension Pickers: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)

        let completion = mediaCompletion
        let loading = mediaLoading
        mediaCompletion = nil
        mediaLoading = nil

        guard !results.isEmpty, let completion else { return }
        loading?()

        let dir: URL
        do {
            dir = try ZipService.newTempDir()
        } catch {
            completion([])
            return
        }

        let group = DispatchGroup()
        let lock = NSLock()
        var collected: [URL] = []

        for result in results {
            let provider = result.itemProvider
            let ids = provider.registeredTypeIdentifiers
            let typeID = ids.first(where: { id in
                guard let t = UTType(id) else { return false }
                return t.conforms(to: .image) || t.conforms(to: .movie)
            }) ?? ids.first
            guard let typeID else { continue }

            group.enter()
            provider.loadFileRepresentation(forTypeIdentifier: typeID) { url, _ in
                defer { group.leave() }
                guard let url else { return }
                // Файл временный: копируем сразу, внутри обработчика.
                lock.lock()
                defer { lock.unlock() }
                let dest = ZipService.uniqueURL(in: dir, name: url.lastPathComponent)
                do {
                    try FileManager.default.copyItem(at: url, to: dest)
                    collected.append(dest)
                } catch {
                    // пропускаем файл, который не удалось получить
                }
            }
        }

        group.notify(queue: .main) {
            completion(collected.sorted { $0.lastPathComponent < $1.lastPathComponent })
        }
    }
}
