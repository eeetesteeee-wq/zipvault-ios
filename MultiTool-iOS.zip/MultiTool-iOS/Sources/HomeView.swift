import SwiftUI

/// Главное меню Мультитула.
struct HomeView: View {
    @State private var path: [Section] = []

    enum Section: Hashable {
        case archives, passwords, settings
    }

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                AuroraBackground()

                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Spacer()
                            Button { path.append(.settings) } label: {
                                Image(systemName: "gearshape.fill")
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundStyle(Color.white)
                                    .frame(width: 44, height: 44)
                                    .background(.ultraThinMaterial, in: Circle())
                                    .overlay(Circle().strokeBorder(Color.white.opacity(0.28), lineWidth: 1))
                            }
                            .buttonStyle(PressableStyle())
                        }
                        .padding(.top, 4)
                        .appear(0)

                        Text("Мультитул")
                            .font(.system(size: 40, weight: .semibold, design: .rounded))
                            .foregroundStyle(Color.white)
                            .padding(.top, 8)
                            .appear(0.05)

                        Text("Бесплатные инструменты. Работают без интернета")
                            .font(.system(size: 15))
                            .foregroundStyle(Color.white.opacity(0.65))
                            .padding(.top, 6)
                            .padding(.bottom, 32)
                            .appear(0.1)

                        Button { path.append(.archives) } label: {
                            MenuCard(icon: "archivebox.fill", title: "Работа с архивами",
                                     subtitle: "ZIP с паролем: создать, посмотреть, дополнить")
                        }
                        .buttonStyle(PressableStyle())
                        .appear(0.15)

                        MenuCard(icon: "doc.fill", title: "Работа с PDF",
                                 subtitle: "Скоро в версии для iPhone")
                            .opacity(0.5)
                            .padding(.top, 16)
                            .appear(0.2)

                        MenuCard(icon: "doc.text.fill", title: "Работа с Word",
                                 subtitle: "Скоро в версии для iPhone")
                            .opacity(0.5)
                            .padding(.top, 16)
                            .appear(0.25)

                        MenuCard(icon: "music.note", title: "Работа с аудио",
                                 subtitle: "Скоро в версии для iPhone")
                            .opacity(0.5)
                            .padding(.top, 16)
                            .appear(0.3)

                        Button { path.append(.passwords) } label: {
                            MenuCard(icon: "lock.fill", title: "Пароли",
                                     subtitle: "Генератор паролей и проверка надёжности")
                        }
                        .buttonStyle(PressableStyle())
                        .padding(.top, 16)
                        .appear(0.35)

                        Text("Бесплатно · без рекламы · файлы не покидают телефон")
                            .font(.system(size: 12))
                            .foregroundStyle(Color.white.opacity(0.55))
                            .frame(maxWidth: .infinity)
                            .padding(.top, 28)
                            .appear(0.4)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: Section.self) { section in
                switch section {
                case .archives: ArchivesHomeView()
                case .passwords: PasswordMenuView()
                case .settings: SettingsView()
                }
            }
        }
    }
}

struct MenuCard: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 18) {
            IconBadge(systemName: icon, size: 56)
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 20, weight: .medium))
                    .foregroundStyle(Color.white)
                    .multilineTextAlignment(.leading)
                Text(subtitle)
                    .font(.system(size: 14))
                    .foregroundStyle(Color.white.opacity(0.65))
                    .multilineTextAlignment(.leading)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color.white.opacity(0.4))
        }
        .padding(22)
        .frame(maxWidth: .infinity)
        .glassCard(28)
    }
}

/// Заголовок внутреннего экрана раздела.
struct ScreenTitle: View {
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 36, weight: .semibold, design: .rounded))
                .foregroundStyle(Color.white)
            Text(subtitle)
                .font(.system(size: 15))
                .foregroundStyle(Color.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
