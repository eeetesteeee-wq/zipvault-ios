import SwiftUI
import UniformTypeIdentifiers

struct PickedFile: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let size: Int64
    var name: String { url.lastPathComponent }
}

struct CreateView: View {
    @State private var staging: URL?
    @State private var files: [PickedFile] = []
    @State private var archiveName = "Архив"
    @State private var pass1 = ""
    @State private var pass2 = ""
    @State private var showSourceDialog = false
    @State private var loadingMedia = false
    @State private var busy = false
    @State private var toastText: String?

    private var mismatch: Bool { pass1 != pass2 }

    private var subtitle: String {
        if loadingMedia { return "Загружаю фото и видео…" }
        return files.isEmpty ? "Файлы не выбраны" : "Выбрано: \(files.count)"
    }

    var body: some View {
        ZStack {
            AuroraBackground()

            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Новый архив")
                        .font(.system(size: 32, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                    Text(subtitle)
                        .font(.system(size: 14))
                        .foregroundStyle(Color.white.opacity(0.65))
                }
                .appear(0)

                filesCard
                    .appear(0.08)

                Button { showSourceDialog = true } label: {
                    Text(loadingMedia ? "Загружаю…" : "Добавить файлы, фото, видео")
                }
                .buttonStyle(GlassButtonStyle())
                .disabled(loadingMedia || busy)
                .confirmationDialog("Что добавить в архив?", isPresented: $showSourceDialog, titleVisibility: .visible) {
                    Button("Файлы") { pickFiles() }
                    Button("Фото и видео") { pickMedia() }
                }
                .appear(0.14)

                optionsCard
                    .appear(0.2)

                Button { create() } label: {
                    Text(busy ? "Архивирую…" : "Создать архив")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(files.isEmpty || busy || loadingMedia || mismatch)
                .appear(0.26)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 12)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toast($toastText)
    }

    // MARK: - части интерфейса

    private var filesCard: some View {
        Group {
            if files.isEmpty {
                Text("Здесь появятся выбранные файлы, фото и видео")
                    .font(.system(size: 15))
                    .foregroundStyle(Color.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .padding(24)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(files) { file in
                            HStack(spacing: 0) {
                                FileRow(
                                    title: file.name,
                                    subtitle: formatSize(file.size),
                                    systemImage: iconName(for: file.url)
                                )
                                Button { remove(file) } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 22))
                                        .foregroundStyle(Color.white.opacity(0.45))
                                        .padding(.trailing, 12)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(6)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .glassCard()
    }

    private var optionsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 13))
                Text("Имя и пароль (пароль необязателен)")
                    .font(.system(size: 14))
            }
            .foregroundStyle(Color.white.opacity(0.65))

            field {
                TextField("Имя архива", text: $archiveName)
            }
            field {
                SecureField("Пароль", text: $pass1)
            }
            field {
                SecureField("Повторите пароль", text: $pass2)
            }

            if mismatch && !pass2.isEmpty {
                Text("Пароли не совпадают")
                    .font(.system(size: 13))
                    .foregroundStyle(Color(red: 1.0, green: 0.54, blue: 0.5))
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    private func field<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        content()
            .foregroundStyle(Color.white)
            .padding(.horizontal, 16)
            .frame(height: 46)
            .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: - действия

    private func stagingDir() throws -> URL {
        if let dir = staging { return dir }
        let dir = try ZipService.newTempDir()
        staging = dir
        return dir
    }

    private func pickFiles() {
        Pickers.shared.pickFiles(types: [.item], multiple: true) { urls in
            addPicked(urls)
        }
    }

    private func pickMedia() {
        Pickers.shared.pickMedia(
            onLoading: { loadingMedia = true },
            completion: { urls in
                loadingMedia = false
                if urls.isEmpty {
                    toastText = "Не удалось загрузить выбранные фото и видео"
                } else {
                    addPicked(urls)
                }
            }
        )
    }

    private func addPicked(_ urls: [URL]) {
        do {
            let dir = try stagingDir()
            for url in urls {
                let copy = try ZipService.adopt(url, into: dir)
                files.append(PickedFile(url: copy, size: ZipService.fileSize(copy)))
            }
        } catch {
            toastText = "Не удалось добавить файл: \(error.localizedDescription)"
        }
    }

    private func remove(_ file: PickedFile) {
        try? FileManager.default.removeItem(at: file.url)
        withAnimation { files.removeAll { $0.id == file.id } }
    }

    private func create() {
        guard let dir = staging else { return }
        let name = archiveName
        let password = pass1
        busy = true
        Task { @MainActor in
            do {
                let url = try await Task.detached(priority: .userInitiated) {
                    try ZipService.buildArchive(from: dir, name: name, password: password)
                }.value
                busy = false
                Pickers.shared.exportFile(url) { saved in
                    if saved {
                        toastText = "Архив сохранён"
                        resetAfterSave()
                    }
                }
            } catch {
                busy = false
                toastText = error.localizedDescription
            }
        }
    }

    private func resetAfterSave() {
        if let dir = staging { try? FileManager.default.removeItem(at: dir) }
        staging = nil
        files = []
        pass1 = ""
        pass2 = ""
    }
}

/// Значок по типу файла: фото, видео или обычный файл.
func iconName(for url: URL) -> String {
    guard let type = UTType(filenameExtension: url.pathExtension) else { return "doc.fill" }
    if type.conforms(to: .image) { return "photo.fill" }
    if type.conforms(to: .movie) || type.conforms(to: .video) { return "video.fill" }
    return "doc.fill"
}
