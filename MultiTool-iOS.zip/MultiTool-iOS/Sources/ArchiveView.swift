import SwiftUI
import UniformTypeIdentifiers

struct ArchiveView: View {
    let archive: OpenedArchive

    @Environment(\.dismiss) private var dismiss

    @State private var workDir: URL?
    @State private var password: String?
    @State private var entries: [ArchiveEntry] = []
    @State private var askPassword = false
    @State private var wrongPassword = false
    @State private var busy = false
    @State private var loadingMedia = false
    @State private var dirty = false
    @State private var status = "Открываю…"
    @State private var showSourceDialog = false
    @State private var toastText: String?

    var body: some View {
        ZStack {
            AuroraBackground()

            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(archive.name)
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Text(loadingMedia ? "Загружаю фото и видео…" : status)
                        .font(.system(size: 14))
                        .foregroundStyle(Color.white.opacity(0.65))
                }
                .appear(0)

                listCard
                    .appear(0.08)

                Text("Нажмите на файл, чтобы сохранить его из архива")
                    .font(.system(size: 12))
                    .foregroundStyle(Color.white.opacity(0.55))
                    .frame(maxWidth: .infinity)

                HStack(spacing: 12) {
                    Button { showSourceDialog = true } label: {
                        Text(loadingMedia ? "Загружаю…" : "Добавить")
                    }
                    .buttonStyle(GlassButtonStyle())
                    .disabled(workDir == nil || busy || loadingMedia)
                    .confirmationDialog("Что добавить в архив?", isPresented: $showSourceDialog, titleVisibility: .visible) {
                        Button("Файлы") { pickFiles() }
                        Button("Фото и видео") { pickMedia() }
                    }

                    Button { save() } label: {
                        Text("Сохранить")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(!dirty || busy || loadingMedia)
                }
                .appear(0.16)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 12)

            if askPassword {
                PasswordPrompt(
                    wrong: wrongPassword,
                    onCancel: {
                        askPassword = false
                        dismiss()
                    },
                    onSubmit: { pwd in
                        askPassword = false
                        Task { await open(password: pwd) }
                    }
                )
                .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: askPassword)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .task { await open(password: nil) }
        .toast($toastText)
    }

    // MARK: - список

    private var listCard: some View {
        Group {
            if entries.isEmpty {
                Text(workDir == nil ? "Откройте архив, чтобы увидеть файлы" : "Архив пуст")
                    .font(.system(size: 15))
                    .foregroundStyle(Color.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .padding(24)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(entries) { entry in
                            Button { export(entry) } label: {
                                FileRow(
                                    title: entry.path,
                                    subtitle: entry.isDirectory ? "Папка" : formatSize(entry.size),
                                    systemImage: entry.isDirectory
                                        ? "folder.fill"
                                        : iconName(for: URL(fileURLWithPath: entry.path))
                                )
                            }
                            .buttonStyle(.plain)
                            .disabled(entry.isDirectory)
                        }
                    }
                    .padding(6)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .glassCard()
    }

    // MARK: - логика

    private func refreshStatus() {
        let files = entries.filter { !$0.isDirectory }.count
        var text = "Файлов: \(files)"
        if let p = password, !p.isEmpty { text += " · защищён паролем" }
        if dirty { text += " · есть несохранённые изменения" }
        status = text
    }

    @MainActor
    private func open(password pwd: String?) async {
        busy = true
        let url = archive.url
        let encrypted = ZipService.isEncrypted(url)

        if encrypted && (pwd == nil) {
            wrongPassword = false
            askPassword = true
            status = "Нужен пароль"
            busy = false
            return
        }

        do {
            let dir = try await Task.detached(priority: .userInitiated) {
                try ZipService.extract(archive: url, password: pwd)
            }.value
            workDir = dir
            password = pwd
            entries = ZipService.list(dir)
            refreshStatus()
        } catch {
            if encrypted {
                wrongPassword = true
                askPassword = true
                status = "Нужен пароль"
            } else {
                status = "Не удалось открыть архив"
                toastText = error.localizedDescription
            }
        }
        busy = false
    }

    private func export(_ entry: ArchiveEntry) {
        guard let dir = workDir else { return }
        do {
            let url = try ZipService.stageForExport(workDir: dir, relativePath: entry.path)
            Pickers.shared.exportFile(url) { saved in
                if saved { toastText = "Файл сохранён" }
            }
        } catch {
            toastText = error.localizedDescription
        }
    }

    private func pickFiles() {
        Pickers.shared.pickFiles(types: [.item], multiple: true) { urls in
            addPicked(urls)
        }
    }

    private func pickMedia() {
        Pickers.shared.pickMedia(
            onLoading: { loadingMedia = true },
            completion: { urls in
                loadingMedia = false
                if urls.isEmpty {
                    toastText = "Не удалось загрузить выбранные фото и видео"
                } else {
                    addPicked(urls)
                }
            }
        )
    }

    private func addPicked(_ urls: [URL]) {
        guard let dir = workDir else { return }
        do {
            for url in urls {
                _ = try ZipService.adopt(url, into: dir)
            }
            entries = ZipService.list(dir)
            dirty = true
            refreshStatus()
        } catch {
            toastText = "Не удалось добавить файл: \(error.localizedDescription)"
        }
    }

    private func save() {
        guard let dir = workDir else { return }
        let name = (archive.name as NSString).deletingPathExtension
        let pwd = password
        busy = true
        Task { @MainActor in
            do {
                let url = try await Task.detached(priority: .userInitiated) {
                    try ZipService.buildArchive(from: dir, name: name, password: pwd)
                }.value
                busy = false
                Pickers.shared.exportFile(url) { saved in
                    if saved {
                        dirty = false
                        refreshStatus()
                        toastText = "Архив сохранён"
                    }
                }
            } catch {
                busy = false
                toastText = error.localizedDescription
            }
        }
    }
}

// MARK: - окно ввода пароля

private struct PasswordPrompt: View {
    let wrong: Bool
    var onCancel: () -> Void
    var onSubmit: (String) -> Void

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            Color.black.opacity(0.35)
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
                .onTapGesture { }

            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 26))
                    .foregroundStyle(Color.white.opacity(0.9))

                Text("Архив защищён паролем")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(Color.white)

                Text(wrong ? "Неверный пароль. Попробуйте ещё раз" : "Введите пароль, чтобы открыть архив")
                    .font(.system(size: 14))
                    .foregroundStyle(wrong ? Color(red: 1.0, green: 0.54, blue: 0.5) : Color.white.opacity(0.65))

                SecureField("Пароль", text: $text)
                    .focused($focused)
                    .submitLabel(.go)
                    .onSubmit { onSubmit(text) }
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 16)
                    .frame(height: 50)
                    .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                HStack(spacing: 12) {
                    Button("Отмена", action: onCancel)
                        .buttonStyle(GlassButtonStyle())
                    Button("Открыть") { onSubmit(text) }
                        .buttonStyle(PrimaryButtonStyle())
                }
                .padding(.top, 4)
            }
            .padding(24)
            .glassCard(32)
            .padding(.horizontal, 24)
        }
        .onAppear { focused = true }
    }
}
