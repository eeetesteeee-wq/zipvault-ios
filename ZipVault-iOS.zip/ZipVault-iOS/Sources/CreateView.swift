import SwiftUI
import UniformTypeIdentifiers

struct PickedFile: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let size: Int64
    var name: String { url.lastPathComponent }
}

struct CreateView: View {
    @State private var staging: URL?
    @State private var files: [PickedFile] = []
    @State private var archiveName = "Архив"
    @State private var pass1 = ""
    @State private var pass2 = ""
    @State private var showImporter = false
    @State private var busy = false
    @State private var exportURL: URL?
    @State private var showMover = false
    @State private var toastText: String?

    private var mismatch: Bool { pass1 != pass2 }

    var body: some View {
        ZStack {
            AuroraBackground()

            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Новый архив")
                        .font(.system(size: 32, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                    Text(files.isEmpty
                         ? "Файлы не выбраны"
                         : "Выбрано: \(files.count)")
                        .font(.system(size: 14))
                        .foregroundStyle(Color.white.opacity(0.65))
                }
                .appear(0)

                filesCard
                    .appear(0.08)

                Button { showImporter = true } label: {
                    Text("Выбрать файлы")
                }
                .buttonStyle(GlassButtonStyle())
                .appear(0.14)

                optionsCard
                    .appear(0.2)

                Button { create() } label: {
                    Text(busy ? "Архивирую…" : "Создать архив")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(files.isEmpty || busy || mismatch)
                .appear(0.26)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 12)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            handlePicked(result)
        }
        .fileMover(isPresented: $showMover, file: exportURL) { result in
            switch result {
            case .success:
                toastText = "Архив сохранён"
                resetAfterSave()
            case .failure(let error):
                if (error as? CocoaError)?.code != .userCancelled {
                    toastText = error.localizedDescription
                }
            }
        }
        .toast($toastText)
    }

    // MARK: - части интерфейса

    private var filesCard: some View {
        Group {
            if files.isEmpty {
                Text("Здесь появятся выбранные файлы")
                    .font(.system(size: 15))
                    .foregroundStyle(Color.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .padding(24)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(files) { file in
                            HStack(spacing: 0) {
                                FileRow(
                                    title: file.name,
                                    subtitle: formatSize(file.size),
                                    systemImage: "doc.fill"
                                )
                                Button { remove(file) } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 22))
                                        .foregroundStyle(Color.white.opacity(0.45))
                                        .padding(.trailing, 12)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(6)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .glassCard()
    }

    private var optionsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 13))
                Text("Имя и пароль (пароль необязателен)")
                    .font(.system(size: 14))
            }
            .foregroundStyle(Color.white.opacity(0.65))

            field {
                TextField("Имя архива", text: $archiveName)
            }
            field {
                SecureField("Пароль", text: $pass1)
            }
            field {
                SecureField("Повторите пароль", text: $pass2)
            }

            if mismatch && !pass2.isEmpty {
                Text("Пароли не совпадают")
                    .font(.system(size: 13))
                    .foregroundStyle(Color(red: 1.0, green: 0.54, blue: 0.5))
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    private func field<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        content()
            .foregroundStyle(Color.white)
            .padding(.horizontal, 16)
            .frame(height: 46)
            .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: - действия

    private func stagingDir() throws -> URL {
        if let dir = staging { return dir }
        let dir = try ZipService.newTempDir()
        staging = dir
        return dir
    }

    private func handlePicked(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            do {
                let dir = try stagingDir()
                for url in urls {
                    let copy = try ZipService.importCopy(url, into: dir)
                    files.append(PickedFile(url: copy, size: ZipService.fileSize(copy)))
                }
            } catch {
                toastText = "Не удалось добавить файл: \(error.localizedDescription)"
            }
        case .failure(let error):
            toastText = error.localizedDescription
        }
    }

    private func remove(_ file: PickedFile) {
        try? FileManager.default.removeItem(at: file.url)
        withAnimation { files.removeAll { $0.id == file.id } }
    }

    private func create() {
        guard let dir = staging else { return }
        let name = archiveName
        let password = pass1
        busy = true
        Task { @MainActor in
            do {
                let url = try await Task.detached(priority: .userInitiated) {
                    try ZipService.buildArchive(from: dir, name: name, password: password)
                }.value
                exportURL = url
                showMover = true
            } catch {
                toastText = error.localizedDescription
            }
            busy = false
        }
    }

    private func resetAfterSave() {
        if let dir = staging { try? FileManager.default.removeItem(at: dir) }
        staging = nil
        files = []
        pass1 = ""
        pass2 = ""
    }
}
