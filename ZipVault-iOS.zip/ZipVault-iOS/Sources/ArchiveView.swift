import SwiftUI
import UniformTypeIdentifiers

struct ArchiveView: View {
    let archive: OpenedArchive

    @Environment(\.dismiss) private var dismiss

    @State private var workDir: URL?
    @State private var password: String?
    @State private var entries: [ArchiveEntry] = []
    @State private var askPassword = false
    @State private var wrongPassword = false
    @State private var busy = false
    @State private var dirty = false
    @State private var status = "Открываю…"
    @State private var showAddImporter = false
    @State private var exportURL: URL?
    @State private var exportIsArchive = false
    @State private var showMover = false
    @State private var toastText: String?

    var body: some View {
        ZStack {
            AuroraBackground()

            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(archive.name)
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Text(status)
                        .font(.system(size: 14))
                        .foregroundStyle(Color.white.opacity(0.65))
                }
                .appear(0)

                listCard
                    .appear(0.08)

                Text("Нажмите на файл, чтобы сохранить его из архива")
                    .font(.system(size: 12))
                    .foregroundStyle(Color.white.opacity(0.55))
                    .frame(maxWidth: .infinity)

                HStack(spacing: 12) {
                    Button { showAddImporter = true } label: {
                        Text("Добавить файлы")
                    }
                    .buttonStyle(GlassButtonStyle())
                    .disabled(workDir == nil || busy)

                    Button { save() } label: {
                        Text("Сохранить")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(!dirty || busy)
                }
                .appear(0.16)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 12)

            if askPassword {
                PasswordPrompt(
                    wrong: wrongPassword,
                    onCancel: {
                        askPassword = false
                        dismiss()
                    },
                    onSubmit: { pwd in
                        askPassword = false
                        Task { await open(password: pwd) }
                    }
                )
                .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: askPassword)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .task { await open(password: nil) }
        .fileImporter(
            isPresented: $showAddImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            handleAdded(result)
        }
        .fileMover(isPresented: $showMover, file: exportURL) { result in
            switch result {
            case .success:
                toastText = "Сохранено"
                if exportIsArchive { dirty = false }
            case .failure(let error):
                if (error as? CocoaError)?.code != .userCancelled {
                    toastText = error.localizedDescription
                }
            }
        }
        .toast($toastText)
    }

    // MARK: - список

    private var listCard: some View {
        Group {
            if entries.isEmpty {
                Text(workDir == nil ? "Откройте архив, чтобы увидеть файлы" : "Архив пуст")
                    .font(.system(size: 15))
                    .foregroundStyle(Color.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .padding(24)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(entries) { entry in
                            Button { export(entry) } label: {
                                FileRow(
                                    title: entry.path,
                                    subtitle: entry.isDirectory ? "Папка" : formatSize(entry.size),
                                    systemImage: entry.isDirectory ? "folder.fill" : "doc.fill"
                                )
                            }
                            .buttonStyle(.plain)
                            .disabled(entry.isDirectory)
                        }
                    }
                    .padding(6)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .glassCard()
    }

    // MARK: - логика

    private func refreshStatus() {
        let files = entries.filter { !$0.isDirectory }.count
        var text = "Файлов: \(files)"
        if let p = password, !p.isEmpty { text += " · защищён паролем" }
        if dirty { text += " · есть несохранённые изменения" }
        status = text
    }

    @MainActor
    private func open(password pwd: String?) async {
        busy = true
        let url = archive.url
        let encrypted = ZipService.isEncrypted(url)

        if encrypted && (pwd == nil) {
            wrongPassword = false
            askPassword = true
            status = "Нужен пароль"
            busy = false
            return
        }

        do {
            let dir = try await Task.detached(priority: .userInitiated) {
                try ZipService.extract(archive: url, password: pwd)
            }.value
            workDir = dir
            password = pwd
            entries = ZipService.list(dir)
            refreshStatus()
        } catch {
            if encrypted {
                wrongPassword = true
                askPassword = true
                status = "Нужен пароль"
            } else {
                status = "Не удалось открыть архив"
                toastText = error.localizedDescription
            }
        }
        busy = false
    }

    private func export(_ entry: ArchiveEntry) {
        guard let dir = workDir else { return }
        do {
            exportURL = try ZipService.stageForExport(workDir: dir, relativePath: entry.path)
            exportIsArchive = false
            showMover = true
        } catch {
            toastText = error.localizedDescription
        }
    }

    private func handleAdded(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let dir = workDir else { return }
            do {
                for url in urls {
                    _ = try ZipService.importCopy(url, into: dir)
                }
                entries = ZipService.list(dir)
                dirty = true
                refreshStatus()
            } catch {
                toastText = "Не удалось добавить файл: \(error.localizedDescription)"
            }
        case .failure(let error):
            toastText = error.localizedDescription
        }
    }

    private func save() {
        guard let dir = workDir else { return }
        let name = (archive.name as NSString).deletingPathExtension
        let pwd = password
        busy = true
        Task { @MainActor in
            do {
                let url = try await Task.detached(priority: .userInitiated) {
                    try ZipService.buildArchive(from: dir, name: name, password: pwd)
                }.value
                exportURL = url
                exportIsArchive = true
                showMover = true
            } catch {
                toastText = error.localizedDescription
            }
            busy = false
        }
    }
}

// MARK: - окно ввода пароля

private struct PasswordPrompt: View {
    let wrong: Bool
    var onCancel: () -> Void
    var onSubmit: (String) -> Void

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            Color.black.opacity(0.35)
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
                .onTapGesture { }

            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 26))
                    .foregroundStyle(Color.white.opacity(0.9))

                Text("Архив защищён паролем")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(Color.white)

                Text(wrong ? "Неверный пароль. Попробуйте ещё раз" : "Введите пароль, чтобы открыть архив")
                    .font(.system(size: 14))
                    .foregroundStyle(wrong ? Color(red: 1.0, green: 0.54, blue: 0.5) : Color.white.opacity(0.65))

                SecureField("Пароль", text: $text)
                    .focused($focused)
                    .submitLabel(.go)
                    .onSubmit { onSubmit(text) }
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 16)
                    .frame(height: 50)
                    .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                HStack(spacing: 12) {
                    Button("Отмена", action: onCancel)
                        .buttonStyle(GlassButtonStyle())
                    Button("Открыть") { onSubmit(text) }
                        .buttonStyle(PrimaryButtonStyle())
                }
                .padding(.top, 4)
            }
            .padding(24)
            .glassCard(32)
            .padding(.horizontal, 24)
        }
        .onAppear { focused = true }
    }
}
